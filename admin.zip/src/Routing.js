import React from 'react'
import { Route, Routes } from 'react-router-dom'
import AddCat from './pages/AddCat'
import Categories from './pages/Categories'
import Home from './pages/Home'
import Login from './pages/Login'
import Profile from './pages/Profile'
import Users from './pages/Users'

function Routing() {
  return (
    <>
    
        <Routes>
            <Route path='/' element={<Login />} />
            <Route path='dashboard' element={<Home />} />
            <Route path='users' element={<Users />} />
            <Route path='profile' element={<Profile />} />
            <Route path='categories' element={<Categories />} />
            <Route path='add-cat' element={<AddCat />} />

        </Routes>
    
    </>
  )
}

export default Routing