const apiUrl="https://mern5pm.herokuapp.com/api/v1/"
const mediaUrl="https://mern5pm.herokuapp.com/images/"

export {apiUrl,mediaUrl}