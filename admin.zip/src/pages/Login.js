import { useState, useEffect } from "react";
import axios from "axios";
import { apiUrl } from "../config";

import {useNavigate} from 'react-router-dom'

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errMsg, setErrMsg] = useState("");

  const navigate=useNavigate()


  useEffect(()=>{
    let em=localStorage.getItem("email")
    if(em){
      navigate("/dashboard")
    }
  },[])


  async function loginUser(e) {
    e.preventDefault();

    if (!email || !password) {
      setErrMsg("Please Fill Fields");
    } else {
      try {
        let res = await axios.post(`${apiUrl}user/login`, { email, password });

        if (res) {
          localStorage.setItem("email", email);
          setErrMsg("");
          navigate("/dashboard")
        }else{
          setErrMsg("Dont Know")
        }
      } catch (err) {
        setErrMsg(err.message);
      }
    }
  }

  return (
    <>
      <div className="jumbotron jumbotron-fluid text-center netflix-gr text-white">
        <h1>Admin Panel</h1>
        <h2>Please Enter Details</h2>
      </div>

      <div className="container my-5">
        <div className="row">
          <div className="col-sm-3"></div>
          <div className="col-sm-6">
            <form onSubmit={loginUser}>
              <div className="form-group">
                <label>Email</label>
                <input
                  type={"email"}
                  onChange={(e) => setEmail(e.target.value)}
                  className="form-control"
                />
              </div>
              <div className="form-group">
                <label>Password</label>
                <input
                  type={"password"}
                  className="form-control"
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <h3 className="text-danger">{errMsg}</h3>
              <button type="submit" className="btn btn-success">
                Login
              </button>
            </form>
          </div>
          <div className="col-sm-3"></div>
        </div>
      </div>
    </>
  );
}

export default Login;
