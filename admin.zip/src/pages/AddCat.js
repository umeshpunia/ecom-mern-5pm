import React, { useState } from "react";
import Navbar from "../components/Navbar";
import axios from 'axios'
import {apiUrl} from '../config'
import { useNavigate } from "react-router-dom";


function AddCat() {
  const [title, setTitle] = useState("");
  const [picture, setPicture] = useState("");
  const [description, setDescription] = useState("");
  const [errMsg, setErrMsg] = useState("");

  const navigate=useNavigate()

  function choosePic(e) {
    let myFile = e.target.files[0];

    let { name } = myFile;

    let fileArr = name.split(".");

    let ext = fileArr[fileArr.length - 1];

    let validExt = ["jpg", "jpeg", "png"];

    if (validExt.includes(ext)) {
      setPicture(myFile);
      setErrMsg("");
    } else {
      e.target.value=""
      setPicture("");
      setErrMsg("Please CHoose Valid Picture");
    }
  }

  async function addCat(e) {
    e.preventDefault();

    if(!title || !description || !picture){
      setErrMsg("Please Fill Correct Things")
    }else{
      try {
        
        let fData=new FormData()

        fData.append("title",title)
        fData.append("picture",picture)
        fData.append("description",description)

        let res=await axios.post(`${apiUrl}category`,fData)
        if(res) {
          setErrMsg("")
          navigate("/categories")
        }

      } catch (error) {
        setErrMsg(error.message)
      }
    }

  }

  return (
    <>
      <Navbar />
      <div className="container my-5">
        <h1 className="my-4 text-center">Add Category</h1>
        <div className="row">
          <div className="col-sm-3"></div>
          <div className="col-sm-6">
            <form onSubmit={addCat}>
              <div className="form-group">
                <label>Title</label>
                <input
                  className="form-control"
                  onChange={(e) => setTitle(e.target.value)}
                  type={"text"}
                />
              </div>
              <div className="form-group">
                <label>Picture</label>
                <input
                  className="form-control"
                  type={"file"}
                  onChange={choosePic}
                />
              </div>
              <div className="form-group">
                <label>Description</label>
                <textarea
                  className="form-control"
                  onChange={(e) => setDescription(e.target.value)}
                ></textarea>
              </div>
              <h3 className="text-danger">{errMsg}</h3>
              <button className="btn btn-warning" type="submit">
                Submit
              </button>
            </form>
          </div>
          <div className="col-sm-3"></div>
        </div>
      </div>
    </>
  );
}

export default AddCat;
