import { useState, useEffect } from "react";
import Navbar from "../components/Navbar";
import axios from "axios";
import { apiUrl } from "../config";

function Users() {
  const [users, setUsers] = useState([]);

  const [errMsg, setErrMsg] = useState("");

  useEffect(() => {
    getUsers();
  }, []);

  async function getUsers() {
    try {
      let res = await axios.get(`${apiUrl}user/users`);
      setUsers(res.data.msg);
    } catch (err) {
      setErrMsg(err.message);
    }
  }

  return (
    <>
      <Navbar />
      <div className="container py-5">
        <h1 className="text-center my-5">Users</h1>
        <table id="myTable" className="table">
          <thead>
            <tr>
              <th>#</th>
              <th>Email</th>
              <th>Add On</th>
              <th>Handle</th>
            </tr>
          </thead>
          <tbody>
            {users?.map((user,index) => {
              return (
                <tr key={user._id}>
                  <th>{index+1}</th>
                  <td>{user.email}</td>
                  <td>{new Date(user.registerOn).toString()}</td>
                  <td>@mdo</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}

export default Users;
