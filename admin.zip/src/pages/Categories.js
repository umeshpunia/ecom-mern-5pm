import { useState, useEffect } from "react";
import Navbar from "../components/Navbar";
import axios from "axios";
import { apiUrl,mediaUrl } from "../config";
import { Link } from "react-router-dom";

function Categories() {
  const [categories, setCategories] = useState([]);

  const [errMsg, setErrMsg] = useState("");

  useEffect(() => {
    getCats();
  }, []);

  async function getCats() {
    try {
      let res = await axios.get(`${apiUrl}category`);
      setCategories(res.data.msg);
    } catch (err) {
      setErrMsg(err.message);
    }
  }

  return (
    <>
      <Navbar />
      <div className="container py-5">
        <h1 className="text-center my-5">Categories</h1>
        <Link to={"/add-cat"} className="btn btn-info my-4">
          Add Category
        </Link>
        <table  className="table">
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Picture</th>
              <th>Handle</th>
            </tr>
          </thead>
          <tbody>
            {categories?.map((cat, index) => {
              return (
                <tr key={cat._id}>
                  <th>{index + 1}</th>
                  <td>{cat.title}</td>
                  <td>
                    <img
                      src={`${mediaUrl}category/${cat.picture}`}
                      height={80}
                    />
                  </td>
                  <td>@mdo</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}

export default Categories;
