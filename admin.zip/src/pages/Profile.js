import React, { useState } from "react";
import Navbar from "../components/Navbar";
import axios from "axios";
import { apiUrl } from "../config";
import { useNavigate } from "react-router-dom";

function Profile() {
  const [op, setOp] = useState("");
  const [np, setNp] = useState("");
  const [cp, setCp] = useState("");
  const [errMsg, setErrMsg] = useState("");

  const navigate=useNavigate()

  async function changePass(e) {
    e.preventDefault();
    let email = localStorage.getItem("email");
    if (!op || !cp || !np) {
      setErrMsg("Please Fill Value");
    } else if (op === np) {
      setErrMsg("Please Choose Different Password");
    } else if (np !== cp) {
      setErrMsg("Please Match Password");
    } else {
      try {
        let res = await axios.patch(`${apiUrl}user/upd`, {
          email,
          op,
          cp,
        });

        localStorage.removeItem("email")
        navigate("/")

      } catch (err) {
        setErrMsg(err.message);
      }
    }
  }

  return (
    <>
      <Navbar />
      <div className="container my-5">
        <h1 className="text-center my-4">Profile</h1>
        <div className="row">
          <div className="col-sm-6"></div>
          <div className="col-sm-6">
            <form onSubmit={changePass}>
              <div className="form-group">
                <label>Old Password</label>
                <input
                  type={"text"}
                  onChange={(e) => setOp(e.target.value)}
                  className="form-control"
                />
              </div>
              <div className="form-group">
                <label>New Password</label>
                <input
                  type={"text"}
                  className="form-control"
                  onChange={(e) => setNp(e.target.value)}
                />
              </div>
              <div className="form-group">
                <label>Confirm Password</label>
                <input
                  type={"text"}
                  className="form-control"
                  onChange={(e) => setCp(e.target.value)}
                />
              </div>
              {errMsg ? <h3 className="alert alert-danger">{errMsg}</h3> : ""}
              <button type="submit" className="btn btn-warning">
                Update Password
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}

export default Profile;
