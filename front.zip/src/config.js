const apiUrl="https://mern5pm.herokuapp.com/api/v1/front/"
const mediaUrl="https://mern5pm.herokuapp.com/images/"

export {apiUrl,mediaUrl}