import React from 'react'
import HomeAbout from '../components/home/HomeAbout'
import HomeServices from '../components/home/HomeServices'
import HomeSlider from '../components/home/HomeSlider'

function Home() {
  return (
    <>
      <HomeSlider />
      <HomeAbout />
      <HomeServices />
    </>
  )
}

export default Home