import React, { useState, useEffect } from "react";
import HeaderTop from "../components/HeaderTop";
import axios from "axios";
import { apiUrl, mediaUrl } from "../config";
import { Link } from "react-router-dom";

function Categories() {
  const [categories, setCategories] = useState([]);
  const [errMsg, setErrMsg] = useState(true);

  useEffect(() => {
    getCats();
  }, []);

  async function getCats() {
    try {
      let res = await axios.get(`${apiUrl}category/all`);
      setCategories(res.data.msg);
      setErrMsg(false);
    } catch (error) {
      setErrMsg(true);
    }
  }

  return (
    <>
      <HeaderTop pageTitle={"Categories"} />
      <div className="container">
        <div className="row">
          {errMsg ? (
            <h1>Something Wrong Please Wait</h1>
          ) : (
            categories?.map((v, i) => (
              <div className="col-sm-4 my-4" key={i}>
                <div className="card">
                  <img
                    src={`${mediaUrl}category/${v.picture}`}
                    className="card-img-top"
                    alt="..."
                  />
                  <div className="card-body">
                    <h5 className="card-title text-center">
                      {v.title.toUpperCase()}
                    </h5>
                    <p
                      className="card-text"
                      style={{ textTransform: "capitalize" }}
                    >
                      {v.description.substr(0, 10)}
                    </p>
                    <Link to={`/category/${v._id}`} className="btn btn-primary">
                      View
                    </Link>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </>
  );
}

export default Categories;
