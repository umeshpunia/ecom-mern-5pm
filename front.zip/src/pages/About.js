import React from 'react'
import HeaderTop from '../components/HeaderTop'
import HomeAbout from '../components/home/HomeAbout'

function About() {
  return (
    <>
        <HeaderTop pageTitle={'About Us'} />
        <HomeAbout />
    </>
  )
}

export default About