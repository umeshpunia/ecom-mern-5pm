import { useState, useEffect } from "react";
import HeaderTop from "../components/HeaderTop";
import { Link, useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import { apiUrl, mediaUrl } from "../config";

function Category() {
  const [category, setCategory] = useState(null);
  const [products, setProducts] = useState([]);
  const [errMsg, setErrMsg] = useState(true);
  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    getCat();
  }, []);

  async function getCat() {
    try {
      let catRes = await axios.get(`${apiUrl}category/${id}`);
      if (catRes.status === 200) {
        setCategory(catRes.data.msg);
        let proRes = await axios.get(`${apiUrl}product/category/${id}`);
        if (proRes.status === 200) {
          if (typeof proRes.data.msg === "string") {
            setErrMsg(true);
          } else {
            setProducts(proRes.data.msg);
            console.log(proRes.data);
            setErrMsg(false);
          }
        } else {
          setErrMsg(true);
        }
      }
    } catch (err) {
      setErrMsg(true);
      navigate("/categories");
    }
  }

  return (
    <>
      <HeaderTop pageTitle={category?.title} />
      <div className="container">
        <div className="row">
          {errMsg ? (
            <h1>Something Wrong Please Wait</h1>
          ) : (
            products?.map((v, i) => (
              <div className="col-sm-4 my-4" key={i}>
                <div className="card">
                  <img
                    src={`${mediaUrl}products/${v.picture}`}
                    className="card-img-top"
                    alt="..."
                  />
                  <div className="card-body">
                    <h5 className="card-title text-center">
                      {v.title.toUpperCase()}
                    </h5>
                    <p
                      className="card-text"
                      style={{ textTransform: "capitalize" }}
                    >
                      {v.description.substr(0, 10)}
                    </p>
                    <Link to={`/product/${v._id}`} className="btn btn-primary">
                      View
                    </Link>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </>
  );
}

export default Category;
