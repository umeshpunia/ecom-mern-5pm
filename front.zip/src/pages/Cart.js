import React, { useEffect, useState } from "react";
import HeaderTop from "../components/HeaderTop";
import { useSelector, useDispatch } from "react-redux";
import { apiUrl, mediaUrl } from "../config";
import { remove } from "../store/slices/cartSlice";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

// rzp_test_BHuueAoUi9GpMq

function Cart() {
  const [isLogin, setIsLogin] = useState(false);
  const navigate=useNavigate()

  useEffect(() => {
    

    if (localStorage.getItem("email")) {
      setIsLogin(true);
    } else {
      setIsLogin(false);
    }
  }, []);

  const cart = useSelector((state) => state.cart);
  const dispatch = useDispatch();

  let cartTotal = 0;

  for (let c of cart) {
    cartTotal = cartTotal + parseInt(c.price);
  }

  function checkoutCart() {
    const options = {
      key: "rzp_test_BHuueAoUi9GpMq",
      amount: cartTotal * 100, // amount should be in paise format i am using here 10 Rupees
      currency: "INR",
      name: "My Ecom", // company name or product name
      description: "hello", // product description
      image: "", // company logo or product image
      modal: {
        // We should prevent closing of the form when esc key is pressed.
        escape: false,
      },
      notes: {
        // include notes if any
      },
      theme: {
        color: "#0c238a",
      },
    };
    options.handler = async (response, error) => {
      options.response = response;
      if (response) {
        // api orders
        let oid = Math.floor(Math.random()*100000)
        for (let c of cart) {
          let myObj = {
            pid: c._id,
            quantity: 1,
            price: c.price,
            email: localStorage.getItem("email"),
            orderId:oid
          };
          try{

          let res = await axios.post(`${apiUrl}place-order`, myObj);
          if(res.status===200){
            dispatch(remove(c))
            
          }
          }catch(err){

          }
        }
      }
      console.log(response); // do whatever you want to do after response
      console.log(error);
      console.log(options);
      // call your backend api to verify payment signature & capture transaction
    };
    options.modal.ondismiss = () => {
      // handle the case when user closes the form while transaction is in progress
      console.log("Transaction cancelled.");
    };
    const rzp = new window.Razorpay(options);
    rzp.open();
  }

  return (
    <>
      <HeaderTop pageTitle={"My Cart"} />
      <div className="container my-5">
        <table className="table">
          <thead>
            <tr>
              <th>#</th>
              <th>Title</th>
              <th>Picture</th>
              <th>Price</th>
              <th>Remove</th>
            </tr>
          </thead>
          <tbody>
            {cart.length > 0 ? (
              cart?.map((pro, index) => (
                <tr key={pro._id}>
                  <th>{index + 1}</th>
                  <td>{pro.title}</td>
                  <td>
                    <img
                      height={50}
                      src={`${mediaUrl}products/${pro?.picture}`}
                      alt=""
                    />
                  </td>
                  <td>&#8377;{pro.price}</td>
                  <td>
                    <button
                      className="btn btn-danger"
                      onClick={() => dispatch(remove(pro))}
                    >
                      X
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <h1>No Cart Data</h1>
            )}
          </tbody>
          <tfoot>
            <tr>
              <td colSpan={4} className="text-center">
                Cart Total
              </td>
              <th>&#8377;{cartTotal}</th>
            </tr>
          </tfoot>
        </table>
        <div className="container text-right pr-5">
          {isLogin ? (
            <button onClick={checkoutCart} className="btn btn-success">
              Checkout
            </button>
          ) : (
            <Link to={"/"} className="btn btn-warning">
              Login
            </Link>
          )}
        </div>
      </div>
    </>
  );
}

export default Cart;
