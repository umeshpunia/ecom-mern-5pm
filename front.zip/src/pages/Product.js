import { useState, useEffect } from "react";
import HeaderTop from "../components/HeaderTop";
import axios from "axios";
import { apiUrl, mediaUrl } from "../config";
import { useNavigate, useParams } from "react-router-dom";

import { useDispatch } from "react-redux";
import { add } from "../store/slices/cartSlice";

function Product() {
  const [product, setProduct] = useState(null);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const { id } = useParams();

  useEffect(() => {
    getPro();
  }, []);

  async function getPro() {
    try {
      let res = await axios.get(`${apiUrl}product/${id}`);
      setProduct(res.data.msg);
    } catch (error) {
      navigate("/");
    }
  }

  return (
    <>
      <HeaderTop pageTitle={product?.title || "Hello"} />
      <div className="container">
        <div className="row">
          <div className="col-sm-6">
            <img src={`${mediaUrl}products/${product?.picture}`} alt="" />
          </div>
          <div className="col-sm-6 py-5">
            {product ? (
              <>
                <h1>Title : {product.title}</h1>
                <h2>Price : &#8377;{product.price}</h2>
                <p>{product.description}</p>

                <button
                  className="btn btn-info"
                  onClick={()=>dispatch(add(product))}
                >
                  Add To Cart
                </button>
              </>
            ) : null}
          </div>
        </div>
      </div>
    </>
  );
}

export default Product;
