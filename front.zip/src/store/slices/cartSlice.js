import { createSlice } from "@reduxjs/toolkit";

export const cartSlice = createSlice({
  name: "cart",
  initialState: [],
  reducers: {
    add: (state, action) => {
      if (state.length > 0) {
        state.push(
          ...state.filter((p) => p._id === action.payload._id),
          action.payload
        );
      } else {
        state.push(action.payload);
      }
    },
    remove: (state, action) => {
      return state.filter((p) => p._id !== action.payload._id);
    },
  },
});

// Action creators are generated for each case reducer function
export const { add, remove } = cartSlice.actions;

export default cartSlice.reducer;
