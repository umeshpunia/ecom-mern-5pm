import React from "react";
import SingleServiceCard from "./SingleServiceCard";

const services = [
  {
    image: "service-1.jpg",
    title: "Fastest Door Delivery",
    description:
      "Sit lorem ipsum et diam elitr est dolor sed duo. Guberg sea et et lorem dolor sed est sit invidunt, dolore tempor diam ipsum takima erat tempor",
    icon: "fa fa-truck service-icon",
  },
  {
    image: "service-2.jpg",
    title: "Fresh Coffee Beans",
    description:
      "Sit lorem ipsum et diam elitr est dolor sed duo. Guberg sea et et lorem dolor sed est sit invidunt, dolore tempor diam ipsum takima erat tempor",
    icon: "fa fa-coffee service-icon",
  },
  {
    image: "service-3.jpg",
    title: "Service 3",
    description:
      "Sit lorem ipsum et diam elitr est dolor sed duo. Guberg sea et et lorem dolor sed est sit invidunt, dolore tempor diam ipsum takima erat tempor",
    icon: "fa fa-award service-icon",
  },
  {
    image: "service-4.jpg",
    title: "Service 4",
    description:
      "Sit lorem ipsum et diam elitr est dolor sed duo. Guberg sea et et lorem dolor sed est sit invidunt, dolore tempor diam ipsum takima erat tempor",
    icon: "fa fa-table service-icon",
  },
];

function HomeServices() {
  return (
    <>
      <div className="container-fluid pt-5">
        <div className="container">
          <div className="section-title">
            <h4
              className="text-primary text-uppercase"
              style={{ letterSpacing: "5px" }}
            >
              Our Services
            </h4>
            <h1 className="display-4">Fresh & Organic Beans</h1>
          </div>
          <div className="row">
            {services?.map((service, index) => (
              <SingleServiceCard
                title={service.title}
                description={service.description}
                image={service.image}
                icon={service.icon}
                key={index}
              />
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

export default HomeServices;
