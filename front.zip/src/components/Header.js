import React from "react";
import { Link } from "react-router-dom";
import {useSelector} from 'react-redux'

function Header() {

  const cart=useSelector(state=>state.cart)

  // console.log(cart)
  return (
    <>
      <div className="container-fluid p-0 nav-bar">
        <nav className="navbar navbar-expand-lg bg-none navbar-dark py-3">
          <a href="index.html" className="navbar-brand px-lg-4 m-0">
            <h1 className="m-0 display-4 text-uppercase text-white">KOPPEE</h1>
          </a>
          <button
            type="button"
            className="navbar-toggler"
            data-toggle="collapse"
            data-target="#navbarCollapse"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div
            className="collapse navbar-collapse justify-content-between"
            id="navbarCollapse"
          >
            <div className="navbar-nav ml-auto p-4">
              <Link to="/" className="nav-item nav-link active">
                Home
              </Link>
              <Link to="/categories" className="nav-item nav-link">
                Categories
              </Link>
              <Link to="/cart" className="nav-item nav-link">
                Cart<sup>{cart.length}</sup>
              </Link>
              <Link to="/about" className="nav-item nav-link">
                About
              </Link>
            </div>
          </div>
        </nav>
      </div>
    </>
  );
}

export default Header;
